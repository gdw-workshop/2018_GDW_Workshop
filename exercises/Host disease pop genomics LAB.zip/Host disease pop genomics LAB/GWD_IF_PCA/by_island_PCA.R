# R code by John Paul, building on code from Alex Buerkle

# read in data
pca.data <- read.csv("by_island_PCA_in_transposed.csv", header=FALSE)

# take a look
dim(pca.data)
pca.data[1:10,1:10]

# run the pca
pcaout <- prcomp(pca.data, center=T, scale.=F)
summary(pcaout)

# view a quick biplot of PC1 and PC2
#plot(pcaout$x[,1],pcaout$x[,2], xlab = "PC 1", ylab = "PC 2")

# create population code vector and convert to data frame; used for labeling points in plot
popframe <- c("Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop1","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop2","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop3","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop4","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop5","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop6","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7","Pop7")
popframe <- as.data.frame(popframe)

# view a nice biplot of PC1 and PC2, with points added below
plot(pcaout$x[,1],pcaout$x[,2],type="n", xlab = "PC 1", ylab = "PC 2")

# add color points
points(pcaout$x[popframe[,1] == "Pop1",1],pcaout$x[popframe[,1] == "Pop1",2],col="darkgray", pch="1", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop2",1],pcaout$x[popframe[,1] == "Pop2",2],col="darkseagreen3", pch="2", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop3",1],pcaout$x[popframe[,1] == "Pop3",2],col="deeppink1", pch="3", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop4",1],pcaout$x[popframe[,1] == "Pop4",2],col="chartreuse2", pch="4", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop5",1],pcaout$x[popframe[,1] == "Pop5",2],col="chocolate1", pch="5", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop6",1],pcaout$x[popframe[,1] == "Pop6",2],col="yellow2", pch="6", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop7",1],pcaout$x[popframe[,1] == "Pop7",2],col="red", pch="7", cex = 1.0)

# view a nice biplot of PC1 and PC3, with points added below
plot(pcaout$x[,1],pcaout$x[,3],type="n", xlab = "PC 1", ylab = "PC 3")

# add color points
points(pcaout$x[popframe[,1] == "Pop1",1],pcaout$x[popframe[,1] == "Pop1",3],col="darkgray", pch="1", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop2",1],pcaout$x[popframe[,1] == "Pop2",3],col="darkseagreen3", pch="2", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop3",1],pcaout$x[popframe[,1] == "Pop3",3],col="deeppink1", pch="3", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop4",1],pcaout$x[popframe[,1] == "Pop4",3],col="chartreuse2", pch="4", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop5",1],pcaout$x[popframe[,1] == "Pop5",3],col="chocolate1", pch="5", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop6",1],pcaout$x[popframe[,1] == "Pop6",3],col="yellow2", pch="6", cex = 1.0)
points(pcaout$x[popframe[,1] == "Pop7",1],pcaout$x[popframe[,1] == "Pop7",3],col="red", pch="7", cex = 1.0)
